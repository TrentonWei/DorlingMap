﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ESRI.ArcGIS.Geometry;

namespace AuxStructureLib
{
    /// <summary>
    /// 邻近图
    /// </summary>
    public class ProxiGraph
    {
        /// <summary>
        /// 点列表
        /// </summary>
        public List<ProxiNode> NodeList = null;
        /// <summary>
        /// 边列表
        /// </summary>
        public List<ProxiEdge> EdgeList = null;
        /// <summary>
        /// 构造函数
        /// </summary>
        public ProxiGraph()
        {
            NodeList = new List<ProxiNode>();
            EdgeList = new List<ProxiEdge>();
        }
        /// <summary>
        /// 创建结点列表
        /// </summary>
        /// <param name="map">地图</param>
        private void CreateNodes(SMap map)
        {
            int nID = 0;
            //点
            if (map.PointList != null)
            {
                foreach (PointObject point in map.PointList)
                {
                    ProxiNode curNode = point.CalProxiNode();
                    curNode.ID = nID;
                    this.NodeList.Add(curNode);
                    nID++;
                }
            }
            //线
            if (map.PolylineList != null)
            {
                foreach (PolylineObject pline in map.PolylineList)
                {
                    ProxiNode curNode = pline.CalProxiNode();
                    curNode.ID = nID;
                    this.NodeList.Add(curNode);
                    nID++;
                }
            }
            //面
            if (map.PolygonList != null)
            {
                foreach (PolygonObject polygon in map.PolygonList)
                {
                    ProxiNode curNode = polygon.CalProxiNode();
                    curNode.ID = nID;
                    this.NodeList.Add(curNode);
                    nID++;
                }
            }
        }


        /// <summary>
        /// 创建边
        /// </summary>
        /// <param name="skeleton">骨架线</param>
        private void CreateEdges(Skeleton skeleton)
        {
            if (skeleton == null || skeleton.Skeleton_ArcList == null || skeleton.Skeleton_ArcList.Count == 0)
            {
                return;
            }
            int curTagID = -1;
            FeatureType curType = FeatureType.Unknown;

            ProxiNode node1 = null;
            ProxiNode node2 = null;

            ProxiEdge curEdge = null;

           // int eID = 0;

            foreach (Skeleton_Arc curArc in skeleton.Skeleton_ArcList)
            {
                if (curArc.LeftMapObj != null && curArc.RightMapObj != null)
                {
                    curTagID = curArc.LeftMapObj.ID;
                    curType = curArc.LeftMapObj.FeatureType;
                    node1 = ProxiNode.GetProxiNodebyTagIDandFType(this.NodeList, curTagID, curType);
                    curTagID = curArc.RightMapObj.ID;
                    curType = curArc.RightMapObj.FeatureType;
                    node2 = ProxiNode.GetProxiNodebyTagIDandFType(this.NodeList, curTagID, curType);
                    curEdge = new ProxiEdge(curArc.ID, node1, node2);
                    this.EdgeList.Add(curEdge);
                    node1.EdgeList.Add(curEdge);
                    node2.EdgeList.Add(curEdge);
                    curEdge.NearestEdge = curArc.NearestEdge;
                    curEdge.Weight = curArc.AveDistance;
                    //eID++;
                }
            }

        }
        /// <summary>
        /// 从骨架线构造邻近图
        /// </summary>
        public void CreateProxiGraphfrmSkeleton(SMap map,Skeleton skeleton)
        {
            CreateNodes(map);
            CreateEdges(skeleton);
        }

        /// <summary>
        /// 写入SHP文件
        /// </summary>
        public void WriteProxiGraph2Shp(esriSRProjCS4Type pri)
        {
            ProxiNode.Create_WriteProxiNodes2Shp(@"E:\DelaunayShape", @"ProxiNodes", this.NodeList, pri);
            ProxiEdge.Create_WriteEdge2Shp(@"E:\DelaunayShape", @"ProxiEdges", this.EdgeList, pri);
            ProxiEdge.Create_WriteNearestDis2Shp(@"E:\DelaunayShape", @"Nearest", this.EdgeList, pri);
        }
    }
}
