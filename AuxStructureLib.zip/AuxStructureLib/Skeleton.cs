﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AuxStructureLib
{
    /// <summary>
    /// 骨架线
    /// </summary>
    public class Skeleton
    {
        //弧段列表
        public List<Skeleton_Arc> Skeleton_ArcList = null;

        //所有伪Voronoi图
        //public List<Pseu_VoronoiPolygon> Pseu_VoronoiPolygonList = null;
        //约束三角网

        public ConsDelaunayTin CDT = null;
        public List<ConNode> ConNodeList = null;
        public SMap Map = null;
        private ConsDelaunayTin cdt;
        private List<ConNode> CNList;


        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="cdt"></param>
        public Skeleton(ConsDelaunayTin cdt, SMap map)
        {
            this.CDT = cdt;
            Map = map;
        }

        public Skeleton(ConsDelaunayTin cdt, List<ConNode> CNList)
        {
            // TODO: Complete member initialization
            this.cdt = cdt;
            this.CNList = CNList;
        }

        /// <summary>
        /// 删除多边形内部三角形
        /// </summary>
        /// <param name="isDAobu">是否删除凹部</param>
        private void PreProcessCDTforPLP(bool isDAobu)
        {
            List<Triangle> delTriList = new List<Triangle>();
            for (int i = 0; i < CDT.TriangleList.Count; i++)
            {
                Triangle curTri = null;
                curTri = CDT.TriangleList[i];
                int tagID = curTri.point1.TagValue;
                if (tagID == curTri.point2.TagValue && tagID == curTri.point3.TagValue)
                {
                    if (curTri.point1.FeatureType != FeatureType.PolygonType)
                    {
                        continue;
                    }

                    if (isDAobu == true)
                    {
                        delTriList.Add(curTri);
                    }
                    else
                    {
                        PolygonObject curPolygon = null;
                        foreach (PolygonObject polygon in Map.PolygonList)
                        {
                            if (polygon.ID == tagID)
                            {
                                curPolygon = polygon;
                                break;
                            }
                        }
                        if (curPolygon == null || curPolygon.PointList.Count < 3)
                            continue;
                        else
                        {
                            TriNode p = ComFunLib.CalCenter(curTri);

                            if (ComFunLib.IsPointinPolygon(p, curPolygon.PointList))
                            {
                                delTriList.Add(curTri);
                            }
                        }

                    }
                }
            }
            foreach (Triangle delTri in delTriList)
            {

                TriEdge e1 = delTri.edge1;
                TriEdge e2 = delTri.edge2;
                TriEdge e3 = delTri.edge3;

                if (e1 != null)
                {
                    TriEdge de = e1.doulEdge;
                    if (de != null)
                    {
                        de.doulEdge = null;
                        de.rightTriangle = null;
                    }
                    CDT.TriEdgeList.Remove(e1);
                }
                if (e2 != null)
                {
                    TriEdge de = e2.doulEdge;
                    if (de != null)
                    {
                        de.doulEdge = null;
                        de.rightTriangle = null;
                    }
                    CDT.TriEdgeList.Remove(e2);
                }
                if (e3 != null)
                {
                    TriEdge de = e3.doulEdge;
                    if (de != null)
                    {
                        de.doulEdge = null;
                        de.rightTriangle = null;
                    }
                    CDT.TriEdgeList.Remove(e3);
                }
                CDT.TriangleList.Remove(delTri);
            }

            //重写ID
            Triangle.WriteID(CDT.TriangleList);
        }

        /// <summary>
        /// 删除同一路段内部三角形
        /// </summary>
        /// <param name="isDAobu"></param>
        private void PreProcessDeleRoadSeg()
        {
            List<int> indexList = new List<int>();
            for (int i = 0; i < CDT.TriangleList.Count; i++)
            {
                Triangle curTri = null;
                curTri = CDT.TriangleList[i];
                int tagID = curTri.point1.TagValue;
                if (tagID == curTri.point2.TagValue && tagID == curTri.point3.TagValue)
                {
                    if (curTri.point1.FeatureType != FeatureType.PolylineType)
                    {
                        continue;
                    }
                    indexList.Add(curTri.ID);
                }
            }

            foreach (int index in indexList)
            {
                foreach (Triangle curTri in CDT.TriangleList)
                {
                    if (curTri.ID == index)
                    {
                        TriEdge e1 = curTri.edge1;
                        TriEdge e2 = curTri.edge2;
                        TriEdge e3 = curTri.edge3;

                        if (e1 != null)
                        {
                            TriEdge de = e1.doulEdge;
                            if (de != null)
                            {
                                de.doulEdge = null;
                                de.rightTriangle = null;
                            }
                            CDT.TriEdgeList.Remove(e1);
                        }
                        if (e2 != null)
                        {
                            TriEdge de = e2.doulEdge;
                            if (de != null)
                            {
                                de.doulEdge = null;
                                de.rightTriangle = null;
                            }
                            CDT.TriEdgeList.Remove(e2);
                        }
                        if (e3 != null)
                        {
                            TriEdge de = e3.doulEdge;
                            if (de != null)
                            {
                                de.doulEdge = null;
                                de.rightTriangle = null;
                            }
                            CDT.TriEdgeList.Remove(e3);
                        }
                        CDT.TriangleList.Remove(curTri);
                        break;
                    }
                }
            }
            //重写ID
            Triangle.WriteID(CDT.TriangleList);
        }
        /// <summary>
        /// 后处理，去除端点出的右边通道
        /// </summary>
        private void PreProcessCDTforRNT()
        {
            if (Map.ConNodeList == null || Map.ConNodeList.Count == 0)
                return;
            //先处理1类三角形中，两个端点的虚边
            foreach (Triangle curTri in CDT.TriangleList)
            {

                if (curTri.TriType == 1)
                {

                    TriEdge vEdge1 = null;
                    TriEdge vEdge2 = null;
                    TriNode vV = null;
                    TriEdge re = curTri.GetVEdgeofT1(out vEdge1, out vEdge2, out vV);
                    //端点在实边上
                    ConNode cNode1 = ConNode.GetPLbyID(Map.ConNodeList, re.startPoint.ID);
                    ConNode cNode2 = ConNode.GetPLbyID(Map.ConNodeList, re.endPoint.ID);
                    ConNode cNode3 = ConNode.GetPLbyID(Map.ConNodeList, vV.ID);
                    //无端点
                    if (cNode1 == null && cNode2 == null && cNode3 == null)
                    {
                        continue;
                    }
                    //三个全是端点
                    else if (cNode1 != null && cNode2 != null && cNode3 != null)
                    {
                        if (vEdge1.rightTriangle != null)
                        {
                            vEdge1.rightTriangle = null;
                            TriEdge dEdge = vEdge1.doulEdge;
                            vEdge1.doulEdge = null;
                            dEdge.rightTriangle = null;
                            dEdge.doulEdge = null;
                        }
                        if (vEdge2.rightTriangle != null)
                        {

                            vEdge2.rightTriangle = null;
                            TriEdge dEdge1 = vEdge2.doulEdge;
                            vEdge2.doulEdge = null;
                            dEdge1.rightTriangle = null;
                            dEdge1.doulEdge = null;
                        }
                    }
                    //有一条虚边的端点均为端点
                    else if (cNode1 != null && cNode2 == null && cNode3 != null)
                    {
                        if (vEdge1.startPoint.ID == cNode1.ID || vEdge1.endPoint.ID == cNode1.ID)
                        {
                            if (vEdge1.rightTriangle != null)
                            {
                                vEdge1.rightTriangle = null;
                                TriEdge dEdge = vEdge1.doulEdge;
                                vEdge1.doulEdge = null;
                                dEdge.rightTriangle = null;
                                dEdge.doulEdge = null;
                            }
                        }
                        else if (vEdge2.startPoint.ID == cNode1.ID || vEdge2.endPoint.ID == cNode1.ID)
                        {
                            if (vEdge2.rightTriangle != null)
                            {
                                vEdge2.rightTriangle = null;
                                TriEdge dEdge1 = vEdge2.doulEdge;
                                vEdge2.doulEdge = null;
                                dEdge1.rightTriangle = null;
                                dEdge1.doulEdge = null;
                            }
                        }
                    }
                    //有一条虚边的端点均为端点
                    else if (cNode1 == null && cNode2 != null && cNode3 != null)
                    {
                        if (vEdge1.startPoint.ID == cNode2.ID || vEdge1.endPoint.ID == cNode2.ID)
                        {
                            if (vEdge1.rightTriangle != null)
                            {
                                vEdge1.rightTriangle = null;
                                TriEdge dEdge = vEdge1.doulEdge;
                                vEdge1.doulEdge = null;
                                dEdge.rightTriangle = null;
                                dEdge.doulEdge = null;
                            }
                        }
                        else if (vEdge2.startPoint.ID == cNode2.ID || vEdge2.endPoint.ID == cNode2.ID)
                        {
                            if (vEdge2.rightTriangle != null)
                            {
                                vEdge2.rightTriangle = null;
                                TriEdge dEdge1 = vEdge2.doulEdge;
                                vEdge2.doulEdge = null;
                                dEdge1.rightTriangle = null;
                                dEdge1.doulEdge = null;
                            }
                        }
                    }

                                        //一条虚边上仅有一个端点，且在实边上
                    else if ((cNode1 != null || cNode2 != null) && cNode3 == null)
                    {
                        if (cNode1 != null && cNode2 == null)
                        {
                            if (vEdge1.startPoint.ID == cNode1.ID || vEdge1.endPoint.ID == cNode1.ID)
                            {
                                Triangle nextTri = vEdge1.rightTriangle;
                                TriEdge nextEdge = vEdge1.doulEdge;
                                TriEdge vNextEdge1 = null;
                                TriEdge vNextEdge2 = null;
                                TriNode vNextV = null;
                                TriEdge nextRe = null;

                                while (nextTri != null && nextTri.TriType == 1)
                                {
                                    nextRe = nextTri.GetVEdgeofT1(out vNextEdge1, out vNextEdge2, out vNextV);
                                    if (vNextV.ID == cNode1.ID)
                                    {
                                        if (nextEdge.ID == vNextEdge1.ID)
                                        {
                                            nextEdge = vNextEdge2;
                                        }
                                        else
                                        {
                                            nextEdge = vNextEdge1;
                                        }
                                        nextTri = nextEdge.rightTriangle;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                if (nextTri != null)
                                {
                                    nextEdge.rightTriangle = null;
                                    TriEdge dEdge = nextEdge.doulEdge;
                                    nextEdge.doulEdge = null;
                                    dEdge.rightTriangle = null;
                                    dEdge.doulEdge = null;
                                }
                            }
                            else if (vEdge2.startPoint.ID == cNode1.ID || vEdge2.endPoint.ID == cNode1.ID)
                            {
                                Triangle nextTri = vEdge2.rightTriangle;
                                TriEdge nextEdge = vEdge2.doulEdge;
                                TriEdge vNextEdge1 = null;
                                TriEdge vNextEdge2 = null;
                                TriNode vNextV = null;
                                TriEdge nextRe = null;

                                while (nextTri != null && nextTri.TriType == 1)
                                {
                                    nextRe = nextTri.GetVEdgeofT1(out vNextEdge1, out vNextEdge2, out vNextV);
                                    if (vNextV.ID == cNode1.ID)
                                    {
                                        if (nextEdge.ID == vNextEdge1.ID)
                                        {
                                            nextEdge = vNextEdge2;
                                        }
                                        else
                                        {
                                            nextEdge = vNextEdge1;
                                        }
                                        nextTri = nextEdge.rightTriangle;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                if (nextTri != null)
                                {
                                    nextEdge.rightTriangle = null;
                                    TriEdge dEdge = nextEdge.doulEdge;
                                    nextEdge.doulEdge = null;
                                    dEdge.rightTriangle = null;
                                    dEdge.doulEdge = null;
                                }
                            }

                        }
                        else if (cNode1 == null && cNode2 != null)
                        {
                            if (vEdge1.startPoint.ID == cNode2.ID || vEdge1.endPoint.ID == cNode2.ID)
                            {
                                Triangle nextTri = vEdge1.rightTriangle;
                                TriEdge nextEdge = vEdge1.doulEdge;
                                TriEdge vNextEdge1 = null;
                                TriEdge vNextEdge2 = null;
                                TriNode vNextV = null;
                                TriEdge nextRe = null;

                                while (nextTri != null && nextTri.TriType == 1)
                                {
                                    nextRe = nextTri.GetVEdgeofT1(out vNextEdge1, out vNextEdge2, out vNextV);
                                    if (vNextV.ID == cNode2.ID)
                                    {
                                        if (nextEdge.ID == vNextEdge1.ID)
                                        {
                                            nextEdge = vNextEdge2;
                                        }
                                        else
                                        {
                                            nextEdge = vNextEdge1;
                                        }
                                        nextTri = nextEdge.rightTriangle;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                if (nextTri != null)
                                {
                                    nextEdge.rightTriangle = null;
                                    TriEdge dEdge = nextEdge.doulEdge;
                                    nextEdge.doulEdge = null;
                                    dEdge.rightTriangle = null;
                                    dEdge.doulEdge = null;
                                }
                            }
                            else if (vEdge2.startPoint.ID == cNode2.ID || vEdge2.endPoint.ID == cNode2.ID)
                            {

                                Triangle nextTri = vEdge2.rightTriangle;
                                TriEdge nextEdge = vEdge2.doulEdge;
                                TriEdge vNextEdge1 = null;
                                TriEdge vNextEdge2 = null;
                                TriNode vNextV = null;
                                TriEdge nextRe = null;

                                while (nextTri != null && nextTri.TriType == 1)
                                {
                                    nextRe = nextTri.GetVEdgeofT1(out vNextEdge1, out vNextEdge2, out vNextV);
                                    if (vNextV.ID == cNode2.ID)
                                    {
                                        if (nextEdge.ID == vNextEdge1.ID)
                                        {
                                            nextEdge = vNextEdge2;
                                        }
                                        else
                                        {
                                            nextEdge = vNextEdge1;
                                        }
                                        nextTri = nextEdge.rightTriangle;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                if (nextTri != null)
                                {
                                    nextEdge.rightTriangle = null;
                                    TriEdge dEdge = nextEdge.doulEdge;
                                    nextEdge.doulEdge = null;
                                    dEdge.rightTriangle = null;
                                    dEdge.doulEdge = null;
                                }
                            }
                        }
                        else if (cNode1 != null && cNode2 != null)
                        {
                            if (vEdge1.startPoint.ID == cNode1.ID || vEdge1.endPoint.ID == cNode1.ID)
                            {
                                Triangle nextTri = vEdge1.rightTriangle;
                                TriEdge nextEdge = vEdge1.doulEdge;
                                TriEdge vNextEdge1 = null;
                                TriEdge vNextEdge2 = null;
                                TriNode vNextV = null;
                                TriEdge nextRe = null;

                                while (nextTri != null && nextTri.TriType == 1)
                                {

                                    nextRe = nextTri.GetVEdgeofT1(out vNextEdge1, out vNextEdge2, out vNextV);
                                    if (vNextV.ID == cNode1.ID)
                                    {
                                        if (nextEdge.ID == vNextEdge1.ID)
                                        {
                                            nextEdge = vNextEdge2;
                                        }
                                        else
                                        {
                                            nextEdge = vNextEdge1;
                                        }
                                        nextTri = nextEdge.rightTriangle;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                if (nextTri != null)
                                {
                                    nextEdge.rightTriangle = null;
                                    TriEdge dEdge = nextEdge.doulEdge;
                                    nextEdge.doulEdge = null;
                                    dEdge.rightTriangle = null;
                                    dEdge.doulEdge = null;
                                }
                            }
                            else if (vEdge2.startPoint.ID == cNode1.ID || vEdge2.endPoint.ID == cNode1.ID)
                            {
                                Triangle nextTri = vEdge2.rightTriangle;
                                TriEdge nextEdge = vEdge2.doulEdge;
                                TriEdge vNextEdge1 = null;
                                TriEdge vNextEdge2 = null;
                                TriNode vNextV = null;
                                TriEdge nextRe = null;

                                while (nextTri != null && nextTri.TriType == 1)
                                {
                                    nextRe = nextTri.GetVEdgeofT1(out vNextEdge1, out vNextEdge2, out vNextV);
                                    if (vNextV.ID == cNode1.ID)
                                    {
                                        if (nextEdge.ID == vNextEdge1.ID)
                                        {
                                            nextEdge = vNextEdge2;
                                        }
                                        else
                                        {
                                            nextEdge = vNextEdge1;
                                        }
                                        nextTri = nextEdge.rightTriangle;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                if (nextTri != null)
                                {
                                    nextEdge.rightTriangle = null;
                                    TriEdge dEdge = nextEdge.doulEdge;
                                    nextEdge.doulEdge = null;
                                    dEdge.rightTriangle = null;
                                    dEdge.doulEdge = null;
                                }
                            }

                            if (vEdge1.startPoint.ID == cNode2.ID || vEdge1.endPoint.ID == cNode2.ID)
                            {
                                Triangle nextTri = vEdge1.rightTriangle;
                                TriEdge nextEdge = vEdge1.doulEdge;
                                TriEdge vNextEdge1 = null;
                                TriEdge vNextEdge2 = null;
                                TriNode vNextV = null;
                                TriEdge nextRe = null;

                                while (nextTri != null && nextTri.TriType == 1)
                                {
                                    nextRe = nextTri.GetVEdgeofT1(out vNextEdge1, out vNextEdge2, out vNextV);
                                    if (vNextV.ID == cNode2.ID)
                                    {
                                        if (nextEdge.ID == vNextEdge1.ID)
                                        {
                                            nextEdge = vNextEdge2;
                                        }
                                        else
                                        {
                                            nextEdge = vNextEdge1;
                                        }
                                        nextTri = nextEdge.rightTriangle;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                if (nextTri != null)
                                {
                                    nextEdge.rightTriangle = null;
                                    TriEdge dEdge = nextEdge.doulEdge;
                                    nextEdge.doulEdge = null;
                                    dEdge.rightTriangle = null;
                                    dEdge.doulEdge = null;
                                }
                            }
                            else if (vEdge2.startPoint.ID == cNode2.ID || vEdge2.endPoint.ID == cNode2.ID)
                            {

                                Triangle nextTri = vEdge2.rightTriangle;
                                TriEdge nextEdge = vEdge2.doulEdge;
                                TriEdge vNextEdge1 = null;
                                TriEdge vNextEdge2 = null;
                                TriNode vNextV = null;
                                TriEdge nextRe = null;

                                while (nextTri != null && nextTri.TriType == 1)
                                {
                                    nextRe = nextTri.GetVEdgeofT1(out vNextEdge1, out vNextEdge2, out vNextV);
                                    if (vNextV.ID == cNode2.ID)
                                    {
                                        if (nextEdge.ID == vNextEdge1.ID)
                                        {
                                            nextEdge = vNextEdge2;
                                        }
                                        else
                                        {
                                            nextEdge = vNextEdge1;
                                        }
                                        nextTri = nextEdge.rightTriangle;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                if (nextTri != null)
                                {
                                    nextEdge.rightTriangle = null;
                                    TriEdge dEdge = nextEdge.doulEdge;
                                    nextEdge.doulEdge = null;
                                    dEdge.rightTriangle = null;
                                    dEdge.doulEdge = null;
                                }
                            }
                        }
                    }
                }
            }


            //foreach (Triangle curTri in CDT.TriangleList)
            //{

            //    if (curTri.TriType == 1)
            //    {

            //        TriEdge vEdge1 = null;
            //        TriEdge vEdge2 = null;
            //        TriNode vV = null;
            //        TriEdge re = curTri.GetVEdgeofT1( out vEdge1, out vEdge2, out vV);
            //        //端点在实边上
            //        ConNode cNode1 = ConNode.GetPLbyID(Map.ConNodeList, re.startPoint.ID);
            //        ConNode cNode2 = ConNode.GetPLbyID(Map.ConNodeList, re.endPoint.ID);
            //        ConNode cNode3 = ConNode.GetPLbyID(Map.ConNodeList, vV.ID);
            //        //无端点
            //        if (cNode1 == null && cNode2 == null && cNode3 == null)
            //        {
            //            continue;
            //        }
            //        //一条虚边上仅有一个端点，且在实边上
            //        else if ((cNode1 != null || cNode2 != null) && cNode3 == null)
            //        {
            //            if (cNode1 != null && cNode2 == null)
            //            {
            //                if (vEdge1.startPoint.ID == cNode1.ID || vEdge1.endPoint.ID == cNode1.ID)
            //                {
            //                    Triangle nextTri = vEdge1.rightTriangle;
            //                    TriEdge nextEdge = vEdge1.doulEdge;
            //                    TriEdge vNextEdge1 = null;
            //                    TriEdge vNextEdge2 = null;
            //                    TriNode vNextV = null;
            //                    TriEdge nextRe = null;

            //                    while (nextTri != null && nextTri.TriType == 1)
            //                    {
            //                        nextRe =nextTri.GetVEdgeofT1(out vNextEdge1, out vNextEdge2, out vNextV);
            //                        if (vNextV.ID == cNode1.ID)
            //                        {
            //                            if (nextEdge.ID == vNextEdge1.ID)
            //                            {
            //                                nextEdge = vNextEdge2;
            //                            }
            //                            else
            //                            {
            //                                nextEdge = vNextEdge1;
            //                            }
            //                            nextTri = nextEdge.rightTriangle;
            //                        }
            //                        else
            //                        {
            //                            break;
            //                        }
            //                    }
            //                    if (nextTri != null)
            //                    {
            //                        nextEdge.rightTriangle = null;
            //                        TriEdge dEdge = nextEdge.doulEdge;
            //                        nextEdge.doulEdge = null;
            //                        dEdge.rightTriangle = null;
            //                        dEdge.doulEdge = null;
            //                    }
            //                }
            //                else if (vEdge2.startPoint.ID == cNode1.ID || vEdge2.endPoint.ID == cNode1.ID)
            //                {
            //                    Triangle nextTri = vEdge2.rightTriangle;
            //                    TriEdge nextEdge = vEdge2.doulEdge;
            //                    TriEdge vNextEdge1 = null;
            //                    TriEdge vNextEdge2 = null;
            //                    TriNode vNextV = null;
            //                    TriEdge nextRe = null;

            //                    while (nextTri != null && nextTri.TriType == 1)
            //                    {
            //                        nextRe = nextTri.GetVEdgeofT1(out vNextEdge1, out vNextEdge2, out vNextV);
            //                        if (vNextV.ID == cNode1.ID)
            //                        {
            //                            if (nextEdge.ID == vNextEdge1.ID)
            //                            {
            //                                nextEdge = vNextEdge2;
            //                            }
            //                            else
            //                            {
            //                                nextEdge = vNextEdge1;
            //                            }
            //                            nextTri = nextEdge.rightTriangle;
            //                        }
            //                        else
            //                        {
            //                            break;
            //                        }
            //                    }
            //                    if (nextTri != null)
            //                    {
            //                        nextEdge.rightTriangle = null;
            //                        TriEdge dEdge = nextEdge.doulEdge;
            //                        nextEdge.doulEdge = null;
            //                        dEdge.rightTriangle = null;
            //                        dEdge.doulEdge = null;
            //                    }
            //                }

            //            }
            //            else if (cNode1 == null && cNode2 != null)
            //            {
            //                if (vEdge1.startPoint.ID == cNode2.ID || vEdge1.endPoint.ID == cNode2.ID)
            //                {
            //                    Triangle nextTri = vEdge1.rightTriangle;
            //                    TriEdge nextEdge = vEdge1.doulEdge;
            //                    TriEdge vNextEdge1 = null;
            //                    TriEdge vNextEdge2 = null;
            //                    TriNode vNextV = null;
            //                    TriEdge nextRe = null;

            //                    while (nextTri != null && nextTri.TriType == 1)
            //                    {
            //                        nextRe = nextTri.GetVEdgeofT1( out vNextEdge1, out vNextEdge2, out vNextV);
            //                        if (vNextV.ID == cNode2.ID)
            //                        {
            //                            if (nextEdge.ID == vNextEdge1.ID)
            //                            {
            //                                nextEdge = vNextEdge2;
            //                            }
            //                            else
            //                            {
            //                                nextEdge = vNextEdge1;
            //                            }
            //                            nextTri = nextEdge.rightTriangle;
            //                        }
            //                        else
            //                        {
            //                            break;
            //                        }
            //                    }
            //                    if (nextTri != null)
            //                    {
            //                        nextEdge.rightTriangle = null;
            //                        TriEdge dEdge = nextEdge.doulEdge;
            //                        nextEdge.doulEdge = null;
            //                        dEdge.rightTriangle = null;
            //                        dEdge.doulEdge = null;
            //                    }
            //                }
            //                else if (vEdge2.startPoint.ID == cNode2.ID || vEdge2.endPoint.ID == cNode2.ID)
            //                {

            //                    Triangle nextTri = vEdge2.rightTriangle;
            //                    TriEdge nextEdge = vEdge2.doulEdge;
            //                    TriEdge vNextEdge1 = null;
            //                    TriEdge vNextEdge2 = null;
            //                    TriNode vNextV = null;
            //                    TriEdge nextRe = null;

            //                    while (nextTri != null && nextTri.TriType == 1)
            //                    {
            //                        nextRe = nextTri.GetVEdgeofT1( out vNextEdge1, out vNextEdge2, out vNextV);
            //                        if (vNextV.ID == cNode2.ID)
            //                        {
            //                            if (nextEdge.ID == vNextEdge1.ID)
            //                            {
            //                                nextEdge = vNextEdge2;
            //                            }
            //                            else
            //                            {
            //                                nextEdge = vNextEdge1;
            //                            }
            //                            nextTri = nextEdge.rightTriangle;
            //                        }
            //                        else
            //                        {
            //                            break;
            //                        }
            //                    }
            //                    if (nextTri != null)
            //                    {
            //                        nextEdge.rightTriangle = null;
            //                        TriEdge dEdge = nextEdge.doulEdge;
            //                        nextEdge.doulEdge = null;
            //                        dEdge.rightTriangle = null;
            //                        dEdge.doulEdge = null;
            //                    }
            //                }
            //            }
            //            else if (cNode1 != null && cNode2 != null)
            //            {
            //                if (vEdge1.startPoint.ID == cNode1.ID || vEdge1.endPoint.ID == cNode1.ID)
            //                {
            //                    Triangle nextTri = vEdge1.rightTriangle;
            //                    TriEdge nextEdge = vEdge1.doulEdge;
            //                    TriEdge vNextEdge1 = null;
            //                    TriEdge vNextEdge2 = null;
            //                    TriNode vNextV = null;
            //                    TriEdge nextRe = null;

            //                    while (nextTri != null && nextTri.TriType == 1)
            //                    {

            //                        nextRe = nextTri.GetVEdgeofT1(out vNextEdge1, out vNextEdge2, out vNextV);
            //                        if (vNextV.ID == cNode1.ID)
            //                        {
            //                            if (nextEdge.ID == vNextEdge1.ID)
            //                            {
            //                                nextEdge = vNextEdge2;
            //                            }
            //                            else
            //                            {
            //                                nextEdge = vNextEdge1;
            //                            }
            //                            nextTri = nextEdge.rightTriangle;
            //                        }
            //                        else
            //                        {
            //                            break;
            //                        }
            //                    }
            //                    if (nextTri != null)
            //                    {
            //                        nextEdge.rightTriangle = null;
            //                        TriEdge dEdge = nextEdge.doulEdge;
            //                        nextEdge.doulEdge = null;
            //                        dEdge.rightTriangle = null;
            //                        dEdge.doulEdge = null;
            //                    }
            //                }
            //                else if (vEdge2.startPoint.ID == cNode1.ID || vEdge2.endPoint.ID == cNode1.ID)
            //                {
            //                    Triangle nextTri = vEdge2.rightTriangle;
            //                    TriEdge nextEdge = vEdge2.doulEdge;
            //                    TriEdge vNextEdge1 = null;
            //                    TriEdge vNextEdge2 = null;
            //                    TriNode vNextV = null;
            //                    TriEdge nextRe = null;

            //                    while (nextTri != null && nextTri.TriType == 1)
            //                    {
            //                        nextRe =nextTri.GetVEdgeofT1( out vNextEdge1, out vNextEdge2, out vNextV);
            //                        if (vNextV.ID == cNode1.ID)
            //                        {
            //                            if (nextEdge.ID == vNextEdge1.ID)
            //                            {
            //                                nextEdge = vNextEdge2;
            //                            }
            //                            else
            //                            {
            //                                nextEdge = vNextEdge1;
            //                            }
            //                            nextTri = nextEdge.rightTriangle;
            //                        }
            //                        else
            //                        {
            //                            break;
            //                        }
            //                    }
            //                    if (nextTri != null)
            //                    {
            //                        nextEdge.rightTriangle = null;
            //                        TriEdge dEdge = nextEdge.doulEdge;
            //                        nextEdge.doulEdge = null;
            //                        dEdge.rightTriangle = null;
            //                        dEdge.doulEdge = null;
            //                    }
            //                }

            //                if (vEdge1.startPoint.ID == cNode2.ID || vEdge1.endPoint.ID == cNode2.ID)
            //                {
            //                    Triangle nextTri = vEdge1.rightTriangle;
            //                    TriEdge nextEdge = vEdge1.doulEdge;
            //                    TriEdge vNextEdge1 = null;
            //                    TriEdge vNextEdge2 = null;
            //                    TriNode vNextV = null;
            //                    TriEdge nextRe = null;

            //                    while (nextTri != null && nextTri.TriType == 1)
            //                    {
            //                        nextRe = nextTri.GetVEdgeofT1( out vNextEdge1, out vNextEdge2, out vNextV);
            //                        if (vNextV.ID == cNode2.ID)
            //                        {
            //                            if (nextEdge.ID == vNextEdge1.ID)
            //                            {
            //                                nextEdge = vNextEdge2;
            //                            }
            //                            else
            //                            {
            //                                nextEdge = vNextEdge1;
            //                            }
            //                            nextTri = nextEdge.rightTriangle;
            //                        }
            //                        else
            //                        {
            //                            break;
            //                        }
            //                    }
            //                    if (nextTri != null)
            //                    {
            //                        nextEdge.rightTriangle = null;
            //                        TriEdge dEdge = nextEdge.doulEdge;
            //                        nextEdge.doulEdge = null;
            //                        dEdge.rightTriangle = null;
            //                        dEdge.doulEdge = null;
            //                    }
            //                }
            //                else if (vEdge2.startPoint.ID == cNode2.ID || vEdge2.endPoint.ID == cNode2.ID)
            //                {

            //                    Triangle nextTri = vEdge2.rightTriangle;
            //                    TriEdge nextEdge = vEdge2.doulEdge;
            //                    TriEdge vNextEdge1 = null;
            //                    TriEdge vNextEdge2 = null;
            //                    TriNode vNextV = null;
            //                    TriEdge nextRe = null;

            //                    while (nextTri != null && nextTri.TriType == 1)
            //                    {
            //                        nextRe = nextTri.GetVEdgeofT1(out vNextEdge1, out vNextEdge2, out vNextV);
            //                        if (vNextV.ID == cNode2.ID)
            //                        {
            //                            if (nextEdge.ID == vNextEdge1.ID)
            //                            {
            //                                nextEdge = vNextEdge2;
            //                            }
            //                            else
            //                            {
            //                                nextEdge = vNextEdge1;
            //                            }
            //                            nextTri = nextEdge.rightTriangle;
            //                        }
            //                        else
            //                        {
            //                            break;
            //                        }
            //                    }
            //                    if (nextTri != null)
            //                    {
            //                        nextEdge.rightTriangle = null;
            //                        TriEdge dEdge = nextEdge.doulEdge;
            //                        nextEdge.doulEdge = null;
            //                        dEdge.rightTriangle = null;
            //                        dEdge.doulEdge = null;
            //                    }
            //                }
            //            }
            //        }
            //    }
            //}
        }

        /// <summary>
        /// 遍历三角形构建骨架线段For道路网
        /// </summary>
        public void TranverseSkeleton_Segment_NT()
        {
            PreProcessCDTforRNT();
            TranverseSkeleton_Arc();
        }

        /// <summary>
        /// 遍历三角形构建骨架线段For道路网
        /// </summary>
        public void TranverseSkeleton_Segment_NT_RoadSeg()
        {
            PreProcessDeleRoadSeg();//将不同路段相同骨架线弧段的三角形列表隔离开
            PreProcessCDTforRNT();
            TranverseSkeleton_Arc();
        }

        /// <summary>
        /// 遍历三角形构建骨架线段For街区
        /// </summary>
        public void TranverseSkeleton_Segment_PLP()
        {
            PreProcessCDTforPLP(true);//删除凹部
            PreProcessCDTforRNT();//路段端点处理
            TranverseSkeleton_Arc();
        }

        /// <summary>
        /// 湖泊
        /// </summary>
        public void TranverseSkeleton_Lakers()
        {
            PreProcessCDTforPLP(true);//删除凹部
            TranverseSkeleton_Arc();
            this.PostProcessSkeforLakers();
        }

        /// <summary>
        /// 对湖泊生成的骨架线作后处理
        /// </summary>
        private void PostProcessSkeforLakers()
        {
            List<Skeleton_Arc> deleteArcs = new List<Skeleton_Arc>();
            foreach (Skeleton_Arc curArc in this.Skeleton_ArcList)
            {     

                if ((curArc.LeftMapObj.ID == curArc.RightMapObj.ID) && (curArc.LeftMapObj.FeatureType == curArc.RightMapObj.FeatureType))
                {
                    deleteArcs.Add(curArc);
                }
            }

            foreach (Skeleton_Arc dArc in deleteArcs)
            {
                this.Skeleton_ArcList.Remove(dArc);
            }
        }

        /// <summary>
        /// 判断三角形是否全部遍历过
        /// </summary>
        /// <param name="tranversed">是否遍历标示数组</param>
        /// <param name="index">当前没有遍历的三角形下标</param>
        /// <returns></returns>
        private bool IsAllTranversed(bool[] tranversed, out int index)
        {
            index = -1;
            for (int i = 0; i < tranversed.Length; i++)
            {
                if (tranversed[i] == false)
                {
                    index = i;
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// 通过遍历构建骨架线
        /// </summary>
        public void TranverseSkeleton_Arc()
        {
            this.Skeleton_ArcList = new List<Skeleton_Arc>();//骨架线弧段列表
            //以下实现遍历三角形形成骨架线段的算法

            //定义栈
            Stack<Triangle> StaTri = new Stack<Triangle>();
            Stack<TriEdge> StaEdge = new Stack<TriEdge>();
            Stack<TriNode> StaCP = new Stack<TriNode>();

            if (this.CDT.TriangleList == null || this.CDT.TriangleList.Count == 0)
                return;

            int TriCount = this.CDT.TriangleList.Count;
            bool[] TriTranversed = new bool[TriCount];
            for (int j = 0; j < TriCount; j++)
            {
                TriTranversed[j] = false;
            }

            Triangle startTri = null;    //起始三角形，可以是2类0类或1类中的单连通者
            Triangle nextTri = null;     //骨架线段中间的三角形
            Skeleton_Arc newArc = null;  //新的一条骨架线段

            TriEdge vedge = null;
            TriEdge ovedge = null;

            int i = 0;
            TriNode cp = null;

            int ArcID = 0;

            //栈不为空或所有的三角形还没有遍历完
            while (StaTri.Count != 0 || i < TriCount)
            {
                if (ArcID == 148)
                {
                    int error = 0;
                }

                #region 骨架线上第一个三角形
                #region 栈中无0类三角形
                if (StaTri.Count == 0)
                {
                    startTri = CDT.TriangleList[i];
                    #region 如果是3类
                    if (startTri.TriType == 3)
                    {
                        TriTranversed[i] = true;
                        TriNode centerV = ComFunLib.CalCenter(startTri);
                        TriEdge FE = null;
                        TriEdge LE = null;
                        TriEdge RE = null;

                        MapObject FO = null;
                        MapObject LO = null;
                        MapObject RO = null;

                        startTri.GetEdgesofT3(out LE, out RE, out FE);
                        int curtagID = -1;
                        FeatureType curType = FeatureType.Unknown;

                        curtagID = FE.tagID;
                        curType = FE.FeatureType;
                        LO = Map.GetObjectbyID(curtagID, curType);

                        curtagID = RE.tagID;
                        curType = RE.FeatureType;
                        RO = Map.GetObjectbyID(curtagID, curType);

                        curtagID = LE.tagID;
                        curType = LE.FeatureType;
                        FO = Map.GetObjectbyID(curtagID, curType);

                        newArc = new Skeleton_Arc(ArcID);
                        newArc.TriangleList.Add(startTri);//加入起始三角形
                        newArc.PointList.Add(startTri.point1);
                        newArc.PointList.Add(centerV);
                        newArc.LeftMapObj = LO;
                        newArc.RightMapObj = RO;
                        newArc.FrontMapObj = FO;
                        newArc.NearestEdge = new NearestEdge(ArcID, new NearestPoint(-1, startTri.point1.X, startTri.point1.Y), new NearestPoint(-1, startTri.point1.X, startTri.point1.Y), 0);
                        newArc.AveDistance = startTri.CalAveDisforT2_3(startTri.point1);
                        this.Skeleton_ArcList.Add(newArc); ArcID++;

                        newArc = new Skeleton_Arc(ArcID);
                        newArc.TriangleList.Add(startTri);//加入起始三角形
                        newArc.PointList.Add(startTri.point2);
                        newArc.PointList.Add(centerV);
                        newArc.LeftMapObj = RO;
                        newArc.RightMapObj = FO;
                        newArc.FrontMapObj = LO;
                        newArc.NearestEdge = new NearestEdge(ArcID, new NearestPoint(-1, startTri.point2.X, startTri.point2.Y), new NearestPoint(-1, startTri.point2.X, startTri.point2.Y), 0);
                        newArc.AveDistance = startTri.CalAveDisforT2_3(startTri.point2);
                        this.Skeleton_ArcList.Add(newArc); ArcID++;

                        newArc = new Skeleton_Arc(ArcID);
                        newArc.TriangleList.Add(startTri);//加入起始三角形
                        newArc.PointList.Add(startTri.point3);
                        newArc.PointList.Add(centerV);
                        newArc.LeftMapObj = FO;
                        newArc.RightMapObj = LO;
                        newArc.FrontMapObj = RO;
                        newArc.NearestEdge = new NearestEdge(ArcID, new NearestPoint(-1, startTri.point3.X, startTri.point3.Y), new NearestPoint(-1, startTri.point3.X, startTri.point3.Y), 0);
                        newArc.AveDistance = startTri.CalAveDisforT2_3(startTri.point3);
                        this.Skeleton_ArcList.Add(newArc); ArcID++;
                        i++;
                        continue;
                    }
                    #endregion

                    #region 不联通1类
                    else if (startTri.TriType == 1 && TriTranversed[i] == false && startTri.IsNoPathT1())
                    {
                        TriEdge vE1 = null;
                        TriEdge vE2 = null;
                        TriEdge rE = null;
                        TriNode vVex = null;

                        rE = startTri.GetVEdgeofT1(out vE1, out vE2, out vVex);
                        NearestPoint nearestPoint;
                        double minDis = startTri.CalMinDisforT1(vVex, rE.startPoint, rE.endPoint, out nearestPoint);
                        if (vE1 == null || vE2 == null)
                        {
                            int error = 0;
                        }

                        TriNode n1 = ComFunLib.CalLineCenterPoint(vE1);
                        TriNode n2 = ComFunLib.CalLineCenterPoint(vE2);
                        string res = ComFunLib.funReturnRightOrLeft(n1, n2, vVex);
                        int curtagID = -1;
                        FeatureType curType = FeatureType.Unknown;

                        newArc = new Skeleton_Arc(ArcID);
                        newArc.TriangleList.Add(startTri);//加入起始三角形
                        newArc.PointList.Add(n1);
                        newArc.PointList.Add(n2);

                        if (res == "LEFT")
                        {
                            curtagID = vVex.TagValue;
                            curType = vVex.FeatureType;
                            newArc.LeftMapObj = Map.GetObjectbyID(curtagID, curType);

                            curtagID = rE.tagID;
                            curType = rE.FeatureType;
                            newArc.RightMapObj = Map.GetObjectbyID(curtagID, curType);

                            newArc.NearestEdge = new NearestEdge(ArcID, new NearestPoint(-1, vVex.X, vVex.Y), nearestPoint, minDis);
                            newArc.AveDistance = minDis;
                        }
                        else
                        {
                            curtagID = vVex.TagValue;
                            curType = vVex.FeatureType;
                            newArc.RightMapObj = Map.GetObjectbyID(curtagID, curType);

                            curtagID = rE.tagID;
                            curType = rE.FeatureType;
                            newArc.LeftMapObj = Map.GetObjectbyID(curtagID, curType);

                            newArc.NearestEdge = new NearestEdge(ArcID, nearestPoint, new NearestPoint(-1, vVex.X, vVex.Y), minDis);
                            newArc.AveDistance = minDis;
                        }
                        TriTranversed[i] = true;
                        this.Skeleton_ArcList.Add(newArc); ArcID++;
                        i++;
                        continue;
                    }
                    #endregion

                    #region 2类或1类
                    else if ((startTri.TriType == 2 && TriTranversed[i] == false) ||
                    (startTri.TriType == 1 && TriTranversed[i] == false && startTri.IsSinglePathT1()))
                    {
                        TriTranversed[i] = true;
                        newArc = new Skeleton_Arc(ArcID);
                        newArc.TriangleList.Add(startTri);//加入起始三角形

                        if (startTri.TriType == 2)
                        {
                            TriEdge LE = null;
                            TriEdge RE = null;

                            //计算并加入起点,并得到下一虚拟边
                            TriNode startP = startTri.GetStartPointofT2(out vedge, out LE, out RE);
                            newArc.PointList.Add(startP);

                            int curtagID = -1;
                            FeatureType curType = FeatureType.Unknown;

                            curtagID = LE.tagID;
                            curType = LE.FeatureType;
                            newArc.LeftMapObj = Map.GetObjectbyID(curtagID, curType);

                            curtagID = RE.tagID;
                            curType = RE.FeatureType;
                            newArc.RightMapObj = Map.GetObjectbyID(curtagID, curType);

                            if (vedge == null)
                            {
                                int error = 0;
                            }

                            newArc.PointList.Add(ComFunLib.CalLineCenterPoint(vedge));
                            newArc.NearestEdge = new NearestEdge(ArcID, new NearestPoint(-1, startP.X, startP.Y), new NearestPoint(-1, startP.X, startP.Y), 0);
                            newArc.AveDistance += 0.5 * vedge.Length;
                        }

                        else if (startTri.TriType == 1) //单连通1类
                        {
                            TriEdge e = startTri.GetStartEdgeofT1();
                            vedge = startTri.GetOtherVEdgeofT1(e);
                            if (vedge == null || e == null)
                            {
                                int error = 0;
                            }
                            TriNode n1 = ComFunLib.CalLineCenterPoint(e);
                            TriNode n2 = ComFunLib.CalLineCenterPoint(vedge);
                            //计算并加入起点和第二个点
                            newArc.PointList.Add(n1);
                            newArc.PointList.Add(n2);
                            SetMapObjsandDistforT1(ref  newArc, startTri, n1, n2);
                        }
                        //计算并加入第二点
                        nextTri = vedge.rightTriangle;
                        i++;
                    }
                    #endregion

                    #region 0类
                    else if (startTri.TriType == 0 && TriTranversed[i] == false)
                    {
                        TriTranversed[i] = true;

                        TriNode centerV = ComFunLib.CalCenter(startTri);
                        newArc = new Skeleton_Arc(ArcID);
                        newArc.TriangleList.Add(startTri);//加入起始三角形
                        newArc.PointList.Add(centerV);

                        if ((startTri.edge1 == null))
                        {
                            int errror = 0;
                        }

                        TriNode n = ComFunLib.CalLineCenterPoint(startTri.edge1);
                        newArc.PointList.Add(n);
                        //
                        //string res = ComFunLib.funReturnRightOrLeft(centerV, n, startTri.edge1.startPoint);
                        //int curtagID = -1;
                        //FeatureType curType = FeatureType.Unknown;
                        //double minDis = startTri.edge1.Length;
                        //if (res == "LEFT")
                        //{
                        //    curtagID = startTri.edge1.startPoint.TagValue;
                        //    curType = startTri.edge1.startPoint.FeatureType;
                        //    newArc.LeftMapObj = Map.GetObjectbyID(curtagID, curType);

                        //    curtagID = startTri.edge1.endPoint.TagValue;
                        //    curType = startTri.edge1.endPoint.FeatureType;
                        //    newArc.RightMapObj = Map.GetObjectbyID(curtagID, curType);

                        //    newArc.NearestEdge = new NearestEdge(ArcID, new NearestPoint(-1, startTri.edge1.startPoint.X, startTri.edge1.startPoint.Y), new NearestPoint(-1, startTri.edge1.endPoint.X, startTri.edge1.endPoint.Y),minDis );
                        //}
                        //else
                        //{
                        //    curtagID = startTri.edge1.endPoint.TagValue;
                        //    curType = startTri.edge1.endPoint.FeatureType;
                        //    newArc.RightMapObj = Map.GetObjectbyID(curtagID, curType);

                        //    curtagID = startTri.edge1.startPoint.TagValue;
                        //    curType = startTri.edge1.startPoint.FeatureType; 
                        //    newArc.LeftMapObj = Map.GetObjectbyID(curtagID, curType);

                        //    newArc.NearestEdge = new NearestEdge(ArcID,
                        //        new NearestPoint(-1, startTri.edge1.endPoint.X, startTri.edge1.endPoint.Y),
                        //        new NearestPoint(-1, startTri.edge1.startPoint.X, startTri.edge1.startPoint.Y),
                        //        minDis);

                        //}
                        //newArc.AveDistance += minDis;
                        //
                        this.SetMapObjectandDistforT0(ref newArc, centerV, n, startTri.edge1);
                        vedge = startTri.edge1;
                        nextTri = vedge.rightTriangle;

                        StaTri.Push(startTri);
                        StaEdge.Push(startTri.edge2);
                        StaCP.Push(centerV);

                        StaTri.Push(startTri);
                        StaEdge.Push(startTri.edge3);
                        StaCP.Push(centerV);
                        i++;
                    }
                    #endregion
                    else
                    {
                        i++;
                        continue;
                    }
                }
                #endregion

                #region 栈中存在0类三角形
                else//栈中存在0类三角形
                {
                    //出栈
                    startTri = StaTri.Pop();
                    vedge = StaEdge.Pop(); //虚边
                    cp = StaCP.Pop();
                    //如果是下一个三角形不为空，但已经被访问过，则说明是已经遍历的环路跳过(vedge.leftTriangle!=null&&TriTranversed[vedge.rightTriangle.ID] == true)
                    if (vedge == null || (vedge.rightTriangle != null && TriTranversed[vedge.rightTriangle.ID] == true && vedge.rightTriangle.ID == startTri.ID))
                    {
                        continue;
                    }

                    newArc = new Skeleton_Arc(ArcID);

                    TriNode n = ComFunLib.CalLineCenterPoint(vedge);
                    newArc.TriangleList.Add(startTri);//加入起始三角形
                    newArc.PointList.Add(cp);//加入起点
                    newArc.PointList.Add(n);//加入第二点

                    //string res = ComFunLib.funReturnRightOrLeft(cp, n, vedge.startPoint);
                    //int curtagID = -1;
                    //FeatureType curType = FeatureType.Unknown;
                    //double minDis = vedge.Length;
                    //if (res == "LEFT")
                    //{
                    //    curtagID = vedge.startPoint.TagValue;
                    //    curType = vedge.startPoint.FeatureType;
                    //    newArc.LeftMapObj = Map.GetObjectbyID(curtagID, curType);

                    //    curtagID = vedge.endPoint.TagValue;
                    //    curType = vedge.endPoint.FeatureType;
                    //    newArc.RightMapObj = Map.GetObjectbyID(curtagID, curType);
                    //    newArc.NearestEdge = new NearestEdge(ArcID, new NearestPoint(-1, vedge.startPoint.X, vedge.startPoint.Y), new NearestPoint(-1, vedge.endPoint.X, vedge.endPoint.Y), minDis);

                    //}
                    //else
                    //{
                    //    curtagID = vedge.endPoint.TagValue;
                    //    curType = vedge.endPoint.FeatureType;
                    //    newArc.RightMapObj = Map.GetObjectbyID(curtagID, curType);

                    //    curtagID = vedge.startPoint.TagValue;
                    //    curType = vedge.startPoint.FeatureType;
                    //    newArc.LeftMapObj = Map.GetObjectbyID(curtagID, curType);
                    //    newArc.NearestEdge = new NearestEdge(ArcID, new NearestPoint(-1, vedge.endPoint.X, vedge.endPoint.Y), new NearestPoint(-1, vedge.startPoint.X, vedge.startPoint.Y), minDis);
                    //}
                    //newArc.AveDistance += minDis;
                    this.SetMapObjectandDistforT0(ref newArc, cp, n, vedge);

                    nextTri = vedge.rightTriangle;
                }
                #endregion

                #endregion

                //循环遍历路径上所有的1类连通三角形，
                //直到遇到2类，0类或半封闭1类三角形为止,或循环链路为止
                #region 遍历中间三角形
                while (nextTri != null && nextTri.TriType == 1 && TriTranversed[nextTri.ID] != true)
                {
                    TriTranversed[nextTri.ID] = true;
                    newArc.TriangleList.Add(nextTri);
                    ovedge = nextTri.GetOtherVEdgeofT1(vedge.doulEdge);
                    if (vedge == null || ovedge == null)
                    {
                        int error = 0;
                    }
                    TriNode n1 = ComFunLib.CalLineCenterPoint(vedge);
                    TriNode n2 = ComFunLib.CalLineCenterPoint(ovedge);
                    newArc.PointList.Add(n2);

                    SetMapObjsandDistforT1(ref newArc, nextTri, n1, n2);
       
                    vedge = ovedge;
                    nextTri = vedge.rightTriangle;
                }
                #endregion

                #region 骨架线段的最后一个三角形

                #region 如果没有邻接三角形，结束遍历
                if (nextTri == null && newArc != null)
                {

                    newArc.AveDistance = newArc.AveDistance / newArc.TriangleList.Count;
                    this.Skeleton_ArcList.Add(newArc); ArcID++;

                    startTri = null;
                    nextTri = null;
                    newArc = null;
                }
                #endregion

                #region  如果是2类三角形
                else if (nextTri != null && nextTri.TriType == 2)
                {
                    TriEdge re = null;
                    TriEdge le = null;
                    TriEdge oe = null;
                    TriTranversed[nextTri.ID] = true;
                    newArc.TriangleList.Add(nextTri);
                    TriNode startP = nextTri.GetStartPointofT2(out oe, out re, out le);
                    newArc.PointList.Add(startP);

                    if (newArc.LeftMapObj == null || newArc.RightMapObj == null)
                    {
                        int curtagID = -1;
                        FeatureType curType = FeatureType.Unknown;
                        curtagID = le.tagID;
                        curType = le.FeatureType;
                        newArc.LeftMapObj = Map.GetObjectbyID(curtagID, curType);

                        curtagID = re.tagID;
                        curType = re.FeatureType;
                        newArc.RightMapObj = Map.GetObjectbyID(curtagID, curType);

                        if (vedge == null)
                        {
                            int error = 0;
                        }

                        newArc.PointList.Add(ComFunLib.CalLineCenterPoint(vedge));
                    }

                    newArc.NearestEdge = new NearestEdge(ArcID, new NearestPoint(-1, startP.X, startP.Y), new NearestPoint(-1, startP.X, startP.Y), 0);
                    newArc.AveDistance += 0.5 * oe.Length;
                    newArc.AveDistance = newArc.AveDistance / newArc.TriangleList.Count;

                    this.Skeleton_ArcList.Add(newArc); ArcID++;

                    startTri = null;
                    nextTri = null;
                    newArc = null;
                }
                #endregion

                #region 如果是0类三角形,进入二叉树模式
                else if (nextTri != null && nextTri.TriType == 0)
                {
                    //结束遍历
                    TriNode centerV = ComFunLib.CalCenter(nextTri);
                    newArc.TriangleList.Add(nextTri);
                    newArc.PointList.Add(centerV);
                    this.Skeleton_ArcList.Add(newArc);
                    //double minDis = vedge.Length;

                    //if (newArc.LeftMapObj == null || newArc.RightMapObj == null)
                    //{
                    //    string res = ComFunLib.funReturnRightOrLeft(newArc.PointList[newArc.PointList.Count - 2], centerV, vedge.startPoint);
                    //    int curtagID = -1;
                    //    FeatureType curType = FeatureType.Unknown;

                    //    if (res == "LEFT")
                    //    {
                    //        if (newArc.LeftMapObj == null)
                    //        {
                    //            curtagID = vedge.startPoint.TagValue;
                    //            curType = vedge.startPoint.FeatureType;
                    //            newArc.LeftMapObj = Map.GetObjectbyID(curtagID, curType);
                    //        }

                    //        if (newArc.RightMapObj == null)
                    //        {
                    //            curtagID = vedge.endPoint.TagValue;
                    //            curType = vedge.endPoint.FeatureType;
                    //            newArc.RightMapObj = Map.GetObjectbyID(curtagID, curType);
                    //        }

                    //        if (newArc.NearestEdge.NearestDistance > minDis)
                    //        {
                    //            newArc.NearestEdge = new NearestEdge(ArcID, new NearestPoint(-1, vedge.startPoint.X, vedge.startPoint.Y), new NearestPoint(-1, vedge.endPoint.X, vedge.endPoint.Y), minDis);
                    //        }
                    //    }
                    //    else
                    //    {
                    //        if (newArc.RightMapObj == null)
                    //        {
                    //            curtagID = vedge.endPoint.TagValue;
                    //            curType = vedge.endPoint.FeatureType;
                    //            newArc.RightMapObj = Map.GetObjectbyID(curtagID, curType);
                    //        }
                    //        if (newArc.LeftMapObj == null)
                    //        {
                    //            curtagID = vedge.startPoint.TagValue;
                    //            curType = vedge.startPoint.FeatureType;
                    //            newArc.LeftMapObj = Map.GetObjectbyID(curtagID, curType);
                    //        }

                    //        if (newArc.NearestEdge.NearestDistance > minDis)
                    //        {
                    //            newArc.NearestEdge = new NearestEdge(ArcID, new NearestPoint(-1, vedge.endPoint.X, vedge.endPoint.Y), new NearestPoint(-1, vedge.startPoint.X, vedge.startPoint.Y), minDis);
                    //        }
                    //    }
                    //}
                    //newArc.AveDistance += minDis;
                    SetMapObjectandDistforT0(ref  newArc, newArc.PointList[newArc.PointList.Count - 2], centerV, vedge);
                    if (TriTranversed[nextTri.ID] != true)
                    {
                        TriTranversed[nextTri.ID] = true;

                        //加入两个分支的起点到栈中
                        TriEdge edge1 = null;
                        TriEdge edge2 = null;

                        nextTri.GetAnother2EdgeofT0(vedge, out edge1, out edge2);

                        StaTri.Push(nextTri);
                        StaEdge.Push(edge1);
                        StaCP.Push(centerV);

                        StaTri.Push(nextTri);
                        StaEdge.Push(edge2);
                        StaCP.Push(centerV);
                    }

                    newArc.AveDistance = newArc.AveDistance / newArc.TriangleList.Count;
                    ArcID++;
                    startTri = null;
                    nextTri = null;
                    newArc = null;
                }
                #endregion
                #endregion
            }
            #region 如果还存在没有遍历的三角形则说明存在环路需要特别处理之
            int index = -1;
            while (!IsAllTranversed(TriTranversed, out index))
            {
                startTri = CDT.TriangleList[index];
                if (startTri.TriType == 1 && TriTranversed[index] == false)
                {
                    TriTranversed[index] = true;
                    newArc = new Skeleton_Arc(ArcID);
                    newArc.TriangleList.Add(startTri);//加入起始三角形

                    TriEdge e = null;

                    if (startTri.edge1.tagID == -1)
                    {
                        e = startTri.edge1;
                    }
                    else if (startTri.edge2.tagID == -1)
                    {
                        e = startTri.edge2;
                    }

                    else if (startTri.edge3.tagID == -1)
                    {
                        e = startTri.edge3;
                    }
                    vedge = startTri.GetOtherVEdgeofT1(e);

                    if (e == null || vedge == null)
                    {
                        int error = 0;
                    }

                    TriNode n1 = ComFunLib.CalLineCenterPoint(e);
                    TriNode n2 = ComFunLib.CalLineCenterPoint(vedge);
                    //计算并加入起点
                    newArc.PointList.Add(n1);
                    //计算并加入第二点
                    newArc.PointList.Add(n2);
                    SetMapObjsandDistforT1(ref newArc, startTri, n1, n2);
                    nextTri = vedge.rightTriangle;
                }
                //循环遍历路径上所有的1类连通三角形，
                //直到遇到2类，0类或半封闭1类三角形为止,或循环链路为止
                #region 遍历中间三角形
                while (nextTri != null && nextTri.TriType == 1 && TriTranversed[nextTri.ID] != true)
                {
                    TriTranversed[nextTri.ID] = true;
                    newArc.TriangleList.Add(nextTri);
                    ovedge = nextTri.GetOtherVEdgeofT1(vedge.doulEdge);

                    if (ovedge == null || vedge == null)
                    {
                        int error = 0;
                    }

                    TriNode n1 = ComFunLib.CalLineCenterPoint(vedge);
                    TriNode n2 = ComFunLib.CalLineCenterPoint(ovedge);
                    newArc.PointList.Add(n2);

                    SetMapObjsandDistforT1(ref newArc, nextTri, n1, n2);

                    vedge = ovedge;
                    nextTri = vedge.rightTriangle;
                }
                #endregion


                #region 如果是环路
                if (nextTri != null && nextTri.TriType == 1 && TriTranversed[nextTri.ID] == true)
                {
                    TriNode endp = newArc.PointList[0];
                    newArc.PointList.Add(endp);//将起点作为终点添加到链表的最后
                    newArc.AveDistance = newArc.AveDistance / newArc.TriangleList.Count;
                    this.Skeleton_ArcList.Add(newArc); ArcID++;
                    startTri = null;
                    nextTri = null;
                    newArc = null;
                }
                #endregion
            }
            #endregion
        }

        ///// <summary>
        ///// 设置0类三角形距离
        ///// </summary>
        ///// <param name="curArc"></param>
        ///// <param name="n1"></param>
        ///// <param name="n2"></param>
        ///// <param name="edge"></param>
        //private void SetDistanceforT0(ref Skeleton_Arc curArc, TriNode n1, TriNode n2, TriEdge edge)
        //{
        //    double minDis = edge.Length;
        //    string res = ComFunLib.funReturnRightOrLeft(n1, n2, edge.startPoint);
        //    if (curArc.NearestEdge.NearestDistance > minDis)
        //    {
        //        if (res == "LEFT")
        //        {
        //            curArc.NearestEdge = new NearestEdge(curArc.ID, new NearestPoint(-1, edge.startPoint.X, edge.startPoint.Y), new NearestPoint(-1, edge.endPoint.X, edge.endPoint.Y), minDis);
        //        }
        //        else
        //        {
        //            curArc.NearestEdge = new NearestEdge(curArc.ID, new NearestPoint(-1, edge.endPoint.X, edge.endPoint.Y), new NearestPoint(-1, edge.startPoint.X, edge.startPoint.Y), minDis);
        //        }
        //    }
        //    curArc.AveDistance += minDis;
        //}
        /// <summary>
        /// 设置0类三角形左右对象和距离
        /// </summary>
        /// <param name="curArc"></param>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <param name="edge"></param>
        private void SetMapObjectandDistforT0(ref Skeleton_Arc curArc, TriNode n1, TriNode n2, TriEdge edge)
        {
            double minDis = edge.Length;
            if (curArc.LeftMapObj == null || curArc.RightMapObj == null)
            {
                string res = ComFunLib.funReturnRightOrLeft(n1, n2, edge.startPoint);
                int curtagID = -1;
                FeatureType curType = FeatureType.Unknown;
                if (res == "LEFT")
                {
                    if (curArc.LeftMapObj == null)
                    {
                        curtagID = edge.startPoint.TagValue;
                        curType = edge.startPoint.FeatureType;
                        curArc.LeftMapObj = Map.GetObjectbyID(curtagID, curType);
                    }
                    if (curArc.RightMapObj == null)
                    {
                        curtagID = edge.endPoint.TagValue;
                        curType = edge.endPoint.FeatureType;
                        curArc.RightMapObj = Map.GetObjectbyID(curtagID, curType);
                    }
                    if (curArc.NearestEdge.NearestDistance > minDis)
                    {
                        curArc.NearestEdge = new NearestEdge(curArc.ID, new NearestPoint(-1, edge.startPoint.X, edge.startPoint.Y), new NearestPoint(-1, edge.endPoint.X, edge.endPoint.Y), minDis);
                    }
                }
                else
                {
                    if (curArc.RightMapObj == null)
                    {
                        curtagID = edge.endPoint.TagValue;
                        curType = edge.endPoint.FeatureType;
                        curArc.RightMapObj = Map.GetObjectbyID(curtagID, curType);
                    }
                    if (curArc.LeftMapObj == null)
                    {
                        curtagID = edge.startPoint.TagValue;
                        curType = edge.startPoint.FeatureType;
                        curArc.LeftMapObj = Map.GetObjectbyID(curtagID, curType);
                    }
                    if (curArc.NearestEdge.NearestDistance > minDis)
                    {
                        curArc.NearestEdge = new NearestEdge(curArc.ID,
                            new NearestPoint(-1, edge.endPoint.X, edge.endPoint.Y),
                            new NearestPoint(-1, edge.startPoint.X, edge.startPoint.Y),
                            minDis);
                    }

                }
               
            }
            else
            {
                string res = ComFunLib.funReturnRightOrLeft(n1, n2, edge.startPoint);
                if (curArc.NearestEdge.NearestDistance > minDis)
                {
                    if (res == "LEFT")
                    {
                        curArc.NearestEdge = new NearestEdge(curArc.ID, new NearestPoint(-1, edge.startPoint.X, edge.startPoint.Y), new NearestPoint(-1, edge.endPoint.X, edge.endPoint.Y), minDis);
                    }
                    else
                    {
                        curArc.NearestEdge = new NearestEdge(curArc.ID, new NearestPoint(-1, edge.endPoint.X, edge.endPoint.Y), new NearestPoint(-1, edge.startPoint.X, edge.startPoint.Y), minDis);
                    }
                }
            }
            curArc.AveDistance += minDis;
        }
        ///// <summary>
        ///// 设置1类三角形的左右对象
        ///// </summary>
        ///// <param name="curArc">骨架线弧段</param>
        ///// <param name="tri">三角形</param>
        ///// <param name="n1">第一点</param>
        ///// <param name="n2">第二点</param>
        //private void SetDistanceforT1(ref Skeleton_Arc curArc, Triangle tri, TriNode n1, TriNode n2)
        //{
        //    TriEdge vE1 = null;
        //    TriEdge vE2 = null;
        //    TriEdge rE = null;
        //    TriNode vVex = null;

        //    rE = tri.GetVEdgeofT1(out vE1, out vE2, out vVex);
        //    NearestPoint nearestPoint = null;
        //    double minDis = tri.CalMinDisforT1(vVex, rE.startPoint, rE.endPoint, out nearestPoint);

        //    if (curArc.NearestEdge.NearestDistance > minDis)
        //    {
        //        string res = ComFunLib.funReturnRightOrLeft(n1, n2, vVex);
        //        if (res == "LEFT")
        //            curArc.NearestEdge = new NearestEdge(curArc.ID, new NearestPoint(-1, vVex.X, vVex.Y), nearestPoint, minDis);
        //        else

        //            curArc.NearestEdge = new NearestEdge(curArc.ID, nearestPoint, new NearestPoint(-1, vVex.X, vVex.Y), minDis);
        //    }
        //    curArc.AveDistance += minDis;
        //}
        /// <summary>
        /// 
        /// </summary>
        /// <param name="curArc"></param>
        /// <param name="tri"></param>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        private void SetMapObjsandDistforT1(ref Skeleton_Arc curArc, Triangle tri, TriNode n1, TriNode n2)
        {
            TriEdge vE1 = null;
            TriEdge vE2 = null;
            TriEdge rE = null;
            TriNode vVex = null;

            rE = tri.GetVEdgeofT1(out vE1, out vE2, out vVex);
            NearestPoint nearestPoint = null;
            double minDis = tri.CalMinDisforT1(vVex, rE.startPoint, rE.endPoint, out nearestPoint);

            if (curArc.LeftMapObj == null || curArc.RightMapObj == null)
            {
             
                string res = ComFunLib.funReturnRightOrLeft(n1, n2, vVex);
                int curtagID = -1;
                FeatureType curType = FeatureType.Unknown;
                MapObject mo = null;
                if (res == "LEFT")
                {
                    curtagID = vVex.TagValue;
                    curType = vVex.FeatureType;

                    mo = Map.GetObjectbyID(curtagID, curType);
                    if (mo != null)
                        curArc.LeftMapObj = mo;

                    curtagID = rE.tagID;
                    curType = rE.FeatureType;
                    mo = Map.GetObjectbyID(curtagID, curType);
                    if (mo != null)
                        curArc.RightMapObj = mo;
                    if (curArc.NearestEdge.NearestDistance > minDis)
                    {
                        curArc.NearestEdge = new NearestEdge(curArc.ID, new NearestPoint(-1, vVex.X, vVex.Y), nearestPoint, minDis);
                    }

                }
                else
                {
                    curtagID = vVex.TagValue;
                    curType = vVex.FeatureType;

                    mo = Map.GetObjectbyID(curtagID, curType);
                    if (mo != null)
                        curArc.RightMapObj = mo;

                    curtagID = rE.tagID;
                    curType = rE.FeatureType;
                    mo = Map.GetObjectbyID(curtagID, curType);
                    if (mo != null)
                        curArc.LeftMapObj = mo;

                    if (curArc.NearestEdge.NearestDistance > minDis)
                    {
                        curArc.NearestEdge = new NearestEdge(curArc.ID, nearestPoint, new NearestPoint(-1, vVex.X, vVex.Y), minDis);
                    }

                }
               
            }
            else
            {


                if (curArc.NearestEdge.NearestDistance > minDis)
                {
                    string res = ComFunLib.funReturnRightOrLeft(n1, n2, vVex);
                    if (res == "LEFT")
                        curArc.NearestEdge = new NearestEdge(curArc.ID, new NearestPoint(-1, vVex.X, vVex.Y), nearestPoint, minDis);
                    else

                        curArc.NearestEdge = new NearestEdge(curArc.ID, nearestPoint, new NearestPoint(-1, vVex.X, vVex.Y), minDis);
                }
           
            }
            curArc.AveDistance += minDis;
        }


        /// <summary>
        /// 构建Pseu_VoronoiPolygon
        /// </summary>
        public void CreatePseu_VoronoiPolygon()
        {
            //  Pseu_VoronoiPolygonList = new List<Pseu_VoronoiPolygon>();
            //通过多边形生成算法实现Pseu_VoronoiPolygon
            // ...........\
        }

    }
}
