﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AuxStructureLib
{
    /// <summary>
    /// 结点基础类
    /// </summary>
    public abstract class Node
    {
        public double X;        //坐标
        public double Y;        //坐标
        public int ID;          //编号
    }
}
