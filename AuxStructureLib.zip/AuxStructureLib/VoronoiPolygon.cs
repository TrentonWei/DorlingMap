﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AuxStructureLib
{
    /// <summary>
    /// Voronoi多边形
    /// </summary>
    public class VoronoiPolygon
    {
        public List<TriNode> PointSet = null; //构成VoronoiPolygon的点击
        public TriNode Point = null;          //Voronoi内部点
        public bool IsPolygon = true;         //是否是封闭的多边形
        /// <summary>
        /// 构造函数
        /// </summary>
        public VoronoiPolygon(TriNode point)
        {
            PointSet = new List<TriNode>();
            Point = point;
        }
        /// <summary>
        /// VoronoiPolygonduo多边形
        /// </summary>
        /// <param name="_isPolygon"></param>
        public VoronoiPolygon(bool _isPolygon,TriNode point)
        {
            IsPolygon = _isPolygon;
            PointSet = new List<TriNode>();
            Point = point;
        }
        /// <summary>
        /// 利用格雷厄姆凸包生成算法对m_VoronoiPoint中的
        /// </summary>
        public void CreateVoronoiPolygon()
        {
            if (PointSet == null || PointSet.Count == 0)
                return;
            //构成封闭多边形
            if (this.IsPolygon == true)
            {
                TriNode.GetAssortedPoints(this.PointSet);
                this.PointSet.Add(PointSet[0]);
            }
            else
            {
                TriNode.GetAssortedPoints(this.PointSet);
                this.PointSet.Add(PointSet[0]);
            }
        }
    }
}
