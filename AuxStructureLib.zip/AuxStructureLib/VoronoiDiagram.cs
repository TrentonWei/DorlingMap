﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AuxStructureLib
{
    /// <summary>
    /// Voronoi
    /// </summary>
    public class VoronoiDiagram
    {
        public List<VoronoiPolygon> VorPolygonList = null; //Voronoi多边形列表
        public List<TriNode> PointList = null;             //点集
        DelaunayTin tin  = null;                    //三角网
        ConvexNull convexNull = null;               //点集的凸包

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="PointList"></param>
        public VoronoiDiagram(List<TriNode> pointList)
        {
            PointList = pointList;
            VorPolygonList = new List<VoronoiPolygon>();
        }

        /// <summary>
        /// 创建Voronoi图
        /// </summary>
        public void CreateVoronoiDiagram()
        {
            //创建凸壳
            this.convexNull = new ConvexNull(this.PointList);
            convexNull.CreateConvexNull();
            //创建TIN
            this.tin = new DelaunayTin(this.PointList);
            tin.CreateDelaunayTin(AlgDelaunayType.Side_extent);
            foreach (TriNode point in this.PointList)
            {
                VoronoiPolygon vp = new VoronoiPolygon(point);
                //判断是否凸壳上的点
                int index = 0;
                if(convexNull.ContainPoint(point,out index))
                {
                    vp.IsPolygon = false;
                    int n=PointList.Count;
                    TriEdge edge1 = new TriEdge(point, PointList[(index - 1 + n) % n]);
                    TriEdge edge2 = new TriEdge(point, PointList[index + 1 % n]);

                    foreach (Triangle curTri in tin.TriangleList)
                    {

                        if (curTri.ContainEdge(edge1))
                        {
                            vp.PointSet.Add(edge1.EdgeMidPoint);
                        }
                        else if (curTri.ContainEdge(edge2))
                        {
                            vp.PointSet.Add(edge2.EdgeMidPoint);
                        }
                        else if (curTri.ContainPoint(point))
                        {
                            vp.PointSet.Add(curTri.CircumCenter);
                        }
                    }
                }

                else
                {
                    foreach (Triangle curTri in tin.TriangleList)
                    {
                        if (curTri.ContainPoint(point))
                        {
                            vp.PointSet.Add(curTri.CircumCenter);
                        }
                    }
                }
                vp.CreateVoronoiPolygon();
                if (vp.IsPolygon)
                {
                    this.VorPolygonList.Add(vp);
                }
            }
        }
    }
}
