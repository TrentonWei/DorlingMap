﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AuxStructureLib
{
    public class NearestEdge
    {
        public int ID;//编号
        public NearestPoint Point1;//点1
        public NearestPoint Point2;//点2
        private double nearestDistance=-1;//最近距离字段

        /// <summary>
        /// 最近距离属性
        /// </summary>
        public double NearestDistance
        {
            get 
            {
                if (nearestDistance == -1)
                {
                    nearestDistance = Math.Sqrt((Point1.X - Point2.X) * (Point1.X - Point2.X) + (Point1.Y - Point2.Y) * (Point1.Y - Point2.Y));
                    return nearestDistance;
                }
                else
                    return nearestDistance;
            }
            set
            {
                nearestDistance = value;
            }
        }
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="id">编号</param>
        /// <param name="p1">点1</param>
        /// <param name="p2">点2</param>
        /// <param name="nearestDis">最近距离</param>
        public NearestEdge(int id, NearestPoint p1, NearestPoint p2, double nearestDis)
        {
            this.ID = id;
            this.Point1 = p1;
            this.Point2 = p2;
            this.nearestDistance = nearestDis;
        }

    }
}
