﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AuxStructureLib
{
    public class Skeleton_Arc : PolylineObject
    {
        public MapObject LeftMapObj = null;
        public MapObject RightMapObj = null;
        public MapObject FrontMapObj = null;       //可能并不需要
        public MapObject BackMapObj = null;        //可能并不需要
        public List<Triangle> TriangleList = null; //三角形路径
        public NearestEdge NearestEdge = null;
        public double AveDistance = 0;
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="id">编号</param>
        public Skeleton_Arc(int id)
        {
            ID = id;
            TriangleList = new List<Triangle>();
            PointList = new List<TriNode>();
            NearestEdge = new NearestEdge(-1, null, null, 999999999);
        }
    }
}
