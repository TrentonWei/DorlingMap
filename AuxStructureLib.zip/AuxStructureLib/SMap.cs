﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.ADF;
using ESRI.ArcGIS.SystemUI;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;

namespace AuxStructureLib
{
    /// <summary>
    /// 地图类-用于处理数据读入和组织
    /// </summary>
    public class SMap
    {
        /// <summary>
        /// 数据列表
        /// </summary>
        private List<IFeatureLayer> lyrList = null;
        /// <summary>
        /// 点对象列表
        /// </summary>
        public List<PointObject> PointList = null;
        /// <summary>
        /// 线对象列表
        /// </summary>
        public List<PolylineObject> PolylineList = null;
        /// <summary>
        /// 多边形对象列表
        /// </summary>
        public List<PolygonObject> PolygonList = null;
        /// <summary>
        /// 坐标顶点列表
        /// </summary>
        public List<TriNode> TriNodeList = null;
        /// <summary>
        /// 线的关联点列表
        /// </summary>
        public List<ConNode> ConNodeList = null;
        /// <summary>
        /// 地图构造函数
        /// </summary>
        public SMap(List<IFeatureLayer> lyrs)
        {
            lyrList = lyrs;
        }
        /// <summary>
        /// 从ArcGIS图层中读取地图数据
        /// </summary>
        public void ReadDateFrmEsriLyrs()
        {

            if (lyrList == null || lyrList.Count == 0)
            {
                return;
            }

            #region 创建列表
            int pCount = 0;
            int lCount = 0;
            int aCount = 0;
            foreach (IFeatureLayer curLyr in lyrList)
            {
                if (curLyr.FeatureClass.ShapeType == esriGeometryType.esriGeometryPoint)
                {
                    pCount++;

                }
                else if (curLyr.FeatureClass.ShapeType == esriGeometryType.esriGeometryPolyline)
                {
                    lCount++;
                }
                else if (curLyr.FeatureClass.ShapeType == esriGeometryType.esriGeometryPolygon)
                {
                    aCount++;
                }
            }
            if (pCount > 0)
            {
                PointList = new List<PointObject>();
            }
            if (lCount > 0)
            {
                PolylineList = new List<PolylineObject>();
                ConNodeList = new List<ConNode>();
            }
            if (aCount > 0)
            {
                PolygonList = new List<PolygonObject>();
            }
            TriNodeList = new List<TriNode>();
            #endregion

            int vextexID = 0;

            int pID = -1;
            int plID = -1;
            int ppID = -1;

            foreach (IFeatureLayer curLyr in lyrList)
            {
                IFeatureCursor cursor = null;
                IFeature curFeature = null;
                IGeometry shp = null;
                switch (curLyr.FeatureClass.ShapeType)
                {
                    case esriGeometryType.esriGeometryPoint:
                        {

                            #region 点要素
                            //点要素
                            cursor = curLyr.Search(null, false);

                            while ((curFeature = cursor.NextFeature()) != null)
                            {
                                shp = curFeature.Shape;
                                pID = curFeature.OID;
                                IPoint point = null;
                                //几何图形
                                if (shp.GeometryType == esriGeometryType.esriGeometryPoint)
                                {
                                    point = shp as IPoint;
                                    PointObject curPoint = null;           //当前道路
                                    TriNode curVextex = null;                  //当前关联点
                                    double curX;
                                    double curY;

                                    curX = point.X;
                                    curY = point.Y;
                                    curVextex = new TriNode((float)curX, (float)curY, vextexID, pID, FeatureType.PointType);
                                    curPoint = new PointObject(pID, curVextex);
                                    TriNodeList.Add(curVextex);
                                    PointList.Add(curPoint);
                                    vextexID++;
                                  
                                }

                            }
                            #endregion
                            break;
                        }
                    case esriGeometryType.esriGeometryPolyline:
                        {

                            #region 线要素
                            cursor = curLyr.Search(null, false);
                            curFeature = null;
                            shp = null;
                            while ((curFeature = cursor.NextFeature()) != null)
                            {
                                shp = curFeature.Shape;
                                IPolyline polyline = null;
                                IGeometryCollection pathSet = null;
                                //几何图形
                                if (shp.GeometryType == esriGeometryType.esriGeometryPolyline)
                                {
                                    polyline = shp as IPolyline;
                                    plID = curFeature.OID;
                                    pathSet = polyline as IGeometryCollection;
                                    int count = pathSet.GeometryCount;
                                    //Path对象
                                    IPath curPath = null;
                                    for (int i = 0; i < count; i++)
                                    {
                                        PolylineObject curPL = null;                      //当前道路
                                        TriNode curVextex = null;                  //当前关联点
                                        List<TriNode> curPointList = new List<TriNode>();
                                        double curX;
                                        double curY;

                                        curPath = pathSet.get_Geometry(i) as IPath;
                                        IPointCollection pointSet = curPath as IPointCollection;
                                        int pointCount = pointSet.PointCount;
                                        if (pointCount >= 2)
                                        {
                                            curX = pointSet.get_Point(0).X;
                                            curY = pointSet.get_Point(0).Y;
                                            TriNode cNode = ConNode.GetContainNode(ConNodeList, TriNodeList, curX, curY);
                                            if (cNode == null)   //该关联点还未加入的情况
                                            {
                                                curVextex = new TriNode(curX, curY, vextexID, plID, FeatureType.PolylineType);
                                                TriNodeList.Add(curVextex);
                                                ConNode curNode = new ConNode(vextexID, -1f, curVextex);
                                                ConNodeList.Add(curNode);
                                                curPointList.Add(curVextex);
                                                vextexID++;
                                            }
                                            else //该关联点已经加入的情况
                                            {
                                                curPointList.Add(cNode);
                                            }
                                            //加入中间顶点
                                            for (int j = 1; j < pointCount - 1; j++)
                                            {
                                                curX = pointSet.get_Point(j).X;
                                                curY = pointSet.get_Point(j).Y;
                                                curVextex = new TriNode(curX, curY, vextexID, plID, FeatureType.PolylineType);
                                                TriNodeList.Add(curVextex);
                                                curPointList.Add(curVextex);
                                                vextexID++;
                                            }
                                            //加入终点
                                            curX = pointSet.get_Point(pointCount - 1).X;
                                            curY = pointSet.get_Point(pointCount - 1).Y;
                                            cNode = ConNode.GetContainNode(ConNodeList, TriNodeList, curX, curY);
                                            if (cNode == null)   //该关联点还未加入的情况
                                            {
                                                curVextex = new TriNode((float)curX, (float)curY, vextexID, plID, FeatureType.PolylineType);
                                                TriNodeList.Add(curVextex);

                                                ConNode curNode = new ConNode(vextexID, -1f, curVextex);
                                                ConNodeList.Add(curNode);
                                                curPointList.Add(curVextex);
                                                vextexID++;
                                            }
                                            else //该关联点已经加入的情况
                                            {
                                                curPointList.Add(cNode);
                                            }

                                            //添加起点
                                            curPL = new PolylineObject(plID, curPointList, -1f);
                                            PolylineList.Add(curPL);
                                            //plID++;
                                        }
                                    }
                                }
                            }

                            #endregion
                            break;
                        }

                    case esriGeometryType.esriGeometryPolygon:
                        {

                            #region 面要素
                            cursor = curLyr.Search(null, false);
                            curFeature = null;
                            shp = null;
                            while ((curFeature = cursor.NextFeature()) != null)
                            {
                                shp = curFeature.Shape;
                                IPolygon polygon = null;
                                IGeometryCollection pathSet = null;
                                //几何图形
                                if (shp.GeometryType == esriGeometryType.esriGeometryPolygon)
                                {
                                    ppID = curFeature.OID;
                                    polygon = shp as IPolygon;
                                    pathSet = polygon as IGeometryCollection;
                                    int count = pathSet.GeometryCount;
                                    //Path对象
                                    IPath curPath = null;
                                    for (int i = 0; i < count; i++)
                                    {
                                        PolygonObject curPP = null;                      //当前道路
                                        TriNode curVextex = null;                  //当前关联点
                                        List<TriNode> curPointList = new List<TriNode>();
                                        double curX;
                                        double curY;
                                        curPath = pathSet.get_Geometry(i) as IPath;
                                        IPointCollection pointSet = curPath as IPointCollection;
                                        int pointCount = pointSet.PointCount;
                                        if (pointCount >= 3)
                                        {
                                            //ArcGIS中将起点和终点重复存储
                                            for (int j = 0; j < pointCount - 1; j++)
                                            {
                                                //添加起点
                                                curX = pointSet.get_Point(j).X;
                                                curY = pointSet.get_Point(j).Y;
                                                curVextex = new TriNode(curX, curY, vextexID, ppID, FeatureType.PolygonType);
                                                TriNodeList.Add(curVextex);
                                                curPointList.Add(curVextex);
                                                vextexID++;
                                            }

                                            //添加起点
                                            curPP = new PolygonObject(ppID, curPointList);
                                            this.PolygonList.Add(curPP);
                                            //ppID++;
                                        }
                                    }
                                }
                            }
                            #endregion
                            break;
                        }
                }
            }
        }
        /// <summary>
        /// 加密顶点
        /// </summary>
        /// <param name="k">加密系数，平均距离的多少倍</param>
        public void InterpretatePoint(int k)
        {
            AuxStructureLib.Interpretation Inter = new AuxStructureLib.Interpretation(this.PolylineList, this.PolygonList, this.TriNodeList);
            Inter.Interpretate(k);
            this.PolylineList = Inter.PLList;
            this.PolygonList = Inter.PPList;
        }
        /// <summary>
        /// 获取地图对象
        /// </summary>
        /// <param name="ID">ID</param>
        /// <param name="type">类型</param>
        /// <returns></returns>
        public MapObject GetObjectbyID(int ID, FeatureType type)
        {
            if (type == FeatureType.PointType)
            {
                return PointObject.GetPPbyID(this.PointList, ID);
            }
            else if (type == FeatureType.PolylineType)
            {
                return PolylineObject.GetPLbyID(this.PolylineList, ID);
            }
            else if (type == FeatureType.PolygonType)
            {
                return PolygonObject.GetPPbyID(this.PolygonList, ID);
            }
            else
            {
                return null;
            }
        }
    }
}
